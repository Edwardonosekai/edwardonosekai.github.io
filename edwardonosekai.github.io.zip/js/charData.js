var charData = {
    "Donfk": "Azue Lane(JP)/donfk",
    "Baba": "Azue Lane(JP)/Baba",
    "Maichi": "Azue Lane(JP)/MaichiV3",
    "Mzidion": "Azue Lane(JP)/MZidion",
};